vssadmin delete shadows
